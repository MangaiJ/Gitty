const http = require('http');

const fs = require('fs');

const homePage = fs.readFileSync('index.html');

const aboutPage = fs.readFileSync('about.html');

const server = http.createServer((request,response) => {    
    
    // if(request.url === "/") {

    //     return response.end(homePage)

    // } else if(request.url === "/about") {

    //     return response.end('The About Page')

    // } else if(request.url === "/contact") {

    //     return response.end('The Contact Page')

    // } else {

    //     response.writeHead(404)

    //     return response.end("Page Not found")

    // } 
    
})

server.listen(3000,()=> {
    console.log('App is running on 3000')
})