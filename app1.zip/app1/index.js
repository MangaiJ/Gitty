const path = require('path')

const express = require('express')

const expressEdge = require('express-edge')

const mongoose = require('mongoose')

const app = new express()

const bodyParser = require('body-parser')

const fileUpload = require('express-fileupload')

const Post = require('./database/models/post')

mongoose.connect('mongodb://localhost/node-js-blog', { useNewUrlParser: true }).then(() => {
    console.log("Connected to Database");
}).catch((err) => {
    console.log("Not Connected to Database ERROR! ", err);
});

app.use(fileUpload())

app.use(express.static('public'))

app.use(expressEdge)

app.set('views',`${__dirname}/views`)

app.use(bodyParser.json())

app.use(bodyParser.urlencoded({ extended: true }))

const validateCreatePostMiddleware = (req,res,next) => {
    
    if(!req.files.image || !req.body.username || !req.body.title || !req.body.subtitle || !req.body.content) {
        return res.redirect('/posts/new')
    }

    next() 
}

app.use('/posts/store',validateCreatePostMiddleware)

app.get('/', async (req,res) => {

    const posts = await Post.find({})   
   
    // res.sendFile(path.resolve(__dirname,'pages/index.html'))

    res.render('index',{
        posts

    })
})

app.get('/about', (req,res) => {

    // res.sendFile(path.resolve(__dirname,('pages/about.html')))

    res.render('about')
})

app.get('/post', (req,res) => {

    // res.sendFile(path.resolve(__dirname,('pages/post.html')))

    res.render('post')
})

app.get('/post/:id', async(req,res) => {
        const post = await Post.findById(req.params.id);
        res.render('post',{
            post
        })
})


app.get('/contact', (req,res) => {

    // res.sendFile(path.resolve(__dirname,('pages/contact.html')))

    res.render('contact')
})
app.get('/posts/new', (req,res) => {
    
        // res.sendFile(path.resolve(__dirname,('pages/contact.html')))
    
        res.render('create')
})
app.post('/posts/store', (req,res) => {

    
    console.log(req.files)
    const {image} = req.files

    image.mv(path.resolve(__dirname,'public/posts',image.name),(error)=>{
        Post.create({

            ...req.body,

            image: `/posts/${image.name}`

        },(error,post) =>{
            res.redirect('/')
        })
    })    
   
})
app.listen(4000,()=>{
    console.log('App listening on port 4000')
})